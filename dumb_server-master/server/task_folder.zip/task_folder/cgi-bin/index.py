print("Content-type: text/html")
print()
print("<meta charset='utf-8'><h1>Привет, Яндекс! Я - ваши ночные кошмары!</h1>")